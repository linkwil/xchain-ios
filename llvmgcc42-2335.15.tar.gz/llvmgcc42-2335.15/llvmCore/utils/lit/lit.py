#!/usr/bin/env python

if __name__=='__main__':
    import lit
    lit.main()
